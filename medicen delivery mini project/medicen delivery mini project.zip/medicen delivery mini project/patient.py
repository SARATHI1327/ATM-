def patient():

    name=str(input("Enter your Name :"))
    mobile=int(input("Enter your Valid Mobile Number :"))
    address=str(input("enter your address :"))
    pinno=int(input("Enter your pin code number :"))
    
