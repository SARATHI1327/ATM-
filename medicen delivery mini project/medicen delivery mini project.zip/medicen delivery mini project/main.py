import patient,medicene,payment
print("\n\t welcome")
print("\n\t VMS Medical")
#call to patient page
patient.patient()

#call to medicene function to work main page
medicene.medicine_order()
#call to payment function to work main page
payment.payment()
print("")


