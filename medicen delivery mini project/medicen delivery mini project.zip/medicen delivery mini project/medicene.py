def medicine_order():
    m1 = 'bandages'
    m2 = 'eye__drops'
    m3 = 'cotton__balls'
    m4 = 'antiseptic'
    m5 = 'ice__pack'
    m6 = 'tweezers'
    m7 = 'heat__package'
    m8 = 'alcohol'
    m9 = 'pain killer'
    bandages = 200
    eye__drops = 150
    cotton__balls = 199
    antiseptic = 349
    ice__pack = 299
    tweezers = 199
    heat__package = 449
    alcohol = 179
    pain__killer = 399
    global y
    y = 0
    
    def add_to_total(amount):
        global y
        y += amount
    
    def select_medicine():
        select = int(input("Select a medicine:\n1. bandages\n2. eye__drops\n3. cotton__balls\n4. antiseptic\n5. ice__pack\n6. tweezers\n7. heat__package\n8. alcohol\n9. pain killer\n"))
        
        if select == 1:
            quantity = int(input("Enter the quantity: "))
            amount = quantity * bandages
            print("Total amount:", amount)
            add_to_total(amount)
        elif select == 2:
            quantity = int(input("Enter the quantity: "))
            amount = quantity * eye__drops
            print("Total amount:", amount)
            add_to_total(amount)
        elif select == 3:
            quantity = int(input("Enter the quantity: "))
            amount = quantity * cotton__balls
            print("Total amount:", amount)
            add_to_total(amount)
        elif select == 4:
            quantity = int(input("Enter the quantity: "))
            amount = quantity * antiseptic
            print("Total amount:", amount)
            add_to_total(amount)
        elif select ==5:
            quantity = int(input("Enter the quantity: "))
            amount = quantity * ice__pack
            print("Total amount:", amount)
            add_to_total(amount)
        elif select == 6:
            quantity = int(input("Enter the quantity: "))
            amount = quantity * tweezers
            print("Total amount:", amount)
            add_to_total(amount)
        elif select == 7:
            quantity = int(input("Enter the quantity: "))
            amount = quantity * heat__package
            print("Total amount:", amount)
            add_to_total(amount)
        elif select == 8:
            quantity = int(input("Enter the quantity: "))
            amount = quantity * alcohol
            print("Total amount:", amount)
            add_to_total(amount)
        elif select ==9:
            quantity = int(input("Enter the quantity: "))
            amount = quantity * pain__killer
            print("Total amount:", amount)
            add_to_total(amount)
        
        else:
            print("Invalid option")
    
    select_medicine()
    print("Total:", y)
    
    c = int(input("1. Add more\n2. Confirm order\n"))
    while c == 1:
        select_medicine()
        print("Total:", y)
        c = int(input("1. Add more\n2. Confirm order\n"))
    
    if c == 2:
        print("Order confirmed! Total amount:", y)

# Call the medicine_order function to start the process
medicine_order()
