# Define a global variable with an initial value
global_variable = 10

# Example if-elif conditional statement
user_input = input("Enter a number: ")
number = int(user_input)

if number > 0:
    global_variable += number
    print("Added to global_variable")
elif number < 0:
    global_variable -= number
    print("Subtracted from global_variable")
else:
    print("Number is zero, no change to global_variable")

# Print the final value of global_variable
print("global_variable =", global_variable)
